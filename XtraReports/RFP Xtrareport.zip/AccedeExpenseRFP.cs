﻿namespace DX_WebTemplate.XtraReports
{
    public partial class AccedeExpenseRFP : DevExpress.XtraReports.UI.XtraReport
    {
        public AccedeExpenseRFP()
        {
            InitializeComponent();
        }

    }
}
